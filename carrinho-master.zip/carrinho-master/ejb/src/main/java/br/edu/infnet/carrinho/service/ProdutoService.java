package br.edu.infnet.carrinho.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Arrays;
import java.util.List;

import org.codehaus.jackson.map.ObjectMapper;


import br.edu.infnet.carrinho.modelo.Produto;


public class ProdutoService {	
	
	public static List<Produto> obterLista() throws IOException {
		URL url = new URL("http://localhost:8081/produtos");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setRequestProperty("Accept", "application/json");            
        InputStreamReader in = new InputStreamReader(conn.getInputStream());
        BufferedReader br = new BufferedReader(in);
        String json = br.readLine();
        ObjectMapper mapper = new ObjectMapper(); 
        List<Produto> produtos = Arrays.asList(mapper.readValue(json, Produto[].class));    
        conn.disconnect();
		return produtos;
	}	

}
