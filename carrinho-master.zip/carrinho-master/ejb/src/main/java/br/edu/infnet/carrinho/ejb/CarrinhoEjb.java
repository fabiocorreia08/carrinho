package br.edu.infnet.carrinho.ejb;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateful;

import br.edu.infnet.carrinho.modelo.Cliente;
import br.edu.infnet.carrinho.modelo.Pedido;
import br.edu.infnet.carrinho.modelo.Produto;

@Stateful
public class CarrinhoEjb {

	private Integer count = 1;

	public Produto adicionar(Produto produto) {
		//TODO adiciono na base
		produto.setId(count++);		
		return produto;		
	}
	
	public List<Produto> obterTodos() {
		List<Produto> produtos = new ArrayList<Produto>();		
		return produtos;		
	}
	
	public Cliente obterPorCpf(String cpf) {
		Cliente cliente = new Cliente();
		return cliente;
	}
	
	public Pedido adicionar(Pedido pedido) {		
		return pedido;
	}
	
	
	
}
