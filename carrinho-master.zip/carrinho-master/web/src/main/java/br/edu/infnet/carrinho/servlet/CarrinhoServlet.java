package br.edu.infnet.carrinho.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.edu.infnet.carrinho.ejb.CarrinhoEjb;
import br.edu.infnet.carrinho.modelo.Produto;
import br.edu.infnet.carrinho.service.ClienteService;
import br.edu.infnet.carrinho.service.ProdutoService;



@WebServlet(name = "Carrinho", urlPatterns =  {"/Carrinho","/cart"})
public class CarrinhoServlet extends HttpServlet {

	@Inject
	private CarrinhoEjb carrinho;
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		resp.setContentType("text/html");
		
		req.setAttribute("listaProduto", ProdutoService.obterLista());
		req.getRequestDispatcher("index.jsp").forward(req, resp);
		
		
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		resp.setContentType("text/html");
		
		req.setAttribute("listaCliente", ClienteService.obterById(new Integer(1)));
		req.getRequestDispatcher("index.jsp").forward(req, resp);
		
		
	}

}
